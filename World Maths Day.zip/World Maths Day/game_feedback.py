from random import choice, randint 


class GameFeedback:
    """
    Random message to output to user at game over based on performance. Mostly positive!
    """


    def __init__(self, score: int, categories: dict):
        self.score = score 
        self.categories = categories
        self.get_message_category()
        self.choose_random_message()
    

    def get_message_category(self):
        for category in self.categories:
            if self.score >= category:
                self.messages = self.categories[category]
                return 
    

    def choose_random_message(self):
        self.message = choice(self.messages)


class Level1Feedback(GameFeedback):


    def __init__(self, score):
        super().__init__(score, {
            90:(
                "Hacker?! WOW!",
                "NO JOKE, YOU ARE INSANE!",
                "Overpowered! Keep it up!"
            ),
            70:(
                "Excellent work!",
                "Outstanding!",
                "Well done, great performance!"
            ),
            40:(
                "Good job",
                "Nice work",
                ";)"
            ),
            20:(
                "OK",
                "Not too bad",
                "Good effort"
            ),
            1:(
                "There's always room for improvement!",
                "Let's aim for the top!",
                "Be resilient!"
            ),
            0:(
                "No comments",
                "???",
                ". . .",
            )
        })


class Level2Feedback(GameFeedback):


    def __init__(self, score):
        super().__init__(score, {
            70:(
                "Extremely Shocking Performance!!!",
                "Wow... just wow!",
                "Budding mathematitian on the loose!"
            ),
            55:(
                "Fabulous work!",
                "Super!!!",
                "Absolutely amazing job!"
            ),
            30:(
                "Thumbs up to you",
                ":)",
                "Good work!"
            ),
            15:(
                "Not too shabby",
                "Probably better than most people!!!",
                "Effort is key, well done"
            ),
            1:(
                "Reach for the stars!",
                "Keep on running the race!",
                "Never give up!"
            ),
            0:(
                "OOPS!",
                "Excuse me?",
                "Mathematics at its finest... :|"
            )
        }
        )


class Level3Feedback(GameFeedback):


    def __init__(self, score):
        super().__init__(score, {
            60:(
                "Stunning score!",
                "One million thumbs up to you!",
                ">= 1 point / sec :DDD"
            ),
            47:(
                "You should be proud of yourself!",
                "Exceptional!",
                "Virtually as wonderful as it gets :)"
            ),
            25:(
                "Kudos to you",
                ":D",
                "A good performance right here"
            ),
            12:(
                "Fair enough",
                "Half decent",
                "Alright!"
            ),
            1:(
                "Your mathematical journey has only begun",
                "Go, Go, GO!",
                "Your potential is yet to be unleashed!"
            ),
            0:(
                "Why?",
                "Do you really believe 9 + 10 = 21?",
                "Are you thinking in base 4083142192?"
            )
        })


class Level4Feedback(GameFeedback):


    def __init__(self, score):
        super().__init__(score, {
            53:(
                "Are you hacking? Yesn't!",
                "Perfection.",
                "Surreal score, superb!"
            ),
            40:(
                "V.V.V.Good :)",
                "Extravagant!",
                "Fantastic!!"
            ),
            21:(
                "GOOD!",
                "Nice performance!",
                "Great job"
            ),
            10:(
                "Over 10 is good",
                "Reasonable performance",
                "Okay score!"
            ),
            1:(
                "It only gets better from here!",
                "Getting just 1 is already good",
                "👍"
            ),
            0:(
                "Oh no!",
                "*visible confusion",
                "1 + 1 = 11"
            )
        })


class Level5Feedback(GameFeedback):


    def __init__(self, score):
        super().__init__(score, {
            40:(
                "Godlike Genius!",
                "A master of mathematics!",
                "As fast as light!",
                "⭐⭐⭐⭐⭐⭐⭐⭐⭐⭐"
            ),
            30:(
                "Greeeeeeeat!!!",
                "⭐⭐⭐⭐⭐",
                "I could never!"
            ),
            15:(
                "⭐⭐⭐",
                "Respectable",
                "V. Good"
            ),
            8:(
                "⭐",
                "Nice",
                "Decent!"
            ),
            1:(
                "Your Score > 0 :)",
                "Be better than ever",
                "You can do this!"
            ),
            0:(
                "Competent at maths: False",
                "Welp, room for improvement",
                "World record!"
            )
        })


class Level6Feedback(GameFeedback):


    def __init__(self, score):
        super().__init__(score, {
            30:(
                "Sublime score!",
                "speed + accuracy = success",
                "How is this even possible? :D"
            ),
            22:(
                "Excellent!",
                "Fabulous Work!",
                ":DDDDDDD"
            ),
            10:(
                "Good",
                "Not easy questions, well done!",
                "Great"
            ),
            1:(
                "Hard questions, so getting at least 1 is great!",
                "Keep honing your mental maths skills!",
                "Not bad at all!!!"
            ),
            0:(
                "?",
                "Oh dear",
                "D:"
            )
        })


class Level7Feedback(GameFeedback):


    def __init__(self, score):
        super().__init__(score, {
            22:(
                "High IQ moment! :)",
                "Human Calculator! :)",
                "Do you have logic gates running thru your veins?! :)"
            ),
            16:(
                "⭐ Moderately talented ⭐",
                "Outstanding!"
            ),
            7:(
                "V.good!",
                "Better than you think :)",
                "Nice!"
            ),
            1:(
                "At least you can answer some, better than none ⭐⭐⭐",
                "Good!",
                "Better than most!"
            ),
            0:(
                "Well, the questions are quite hard after all!",
                "Not one?",
                "Sad :("
            )
        })


class Level8Feedback(GameFeedback):


    def __init__(self, score):
        super().__init__(score, {
            15:(
                "Albert Einstein couldn't even achieve this! ;)",
                "IQ > 200 ⭐⭐⭐⭐⭐",
                "⭐ You demonstrate serious talent ⭐ Keep it up!!"
            ),
            8:(
                "Wow! Gifted!",
                "Near mastery!",
                "Out of this world! :D"
            ),
            5:(
                "⭐⭐⭐",
                "Very Very Good!",
                "U know ur stuff :)"
            ),
            1:(
                "Getting even just one is already impressive at times!",
                "Unironically quite good!",
                "⭐ Keep it up ⭐"
            ),
            0:(
                "Oh well, maybe next time",
                "Never Give Up",
                f"The questions are like {randint(1_000_000_001, 9_999_999_999)} * {randint(1_000_000_001, 9_999_999_999)} anyways!"
            )
        })

