from generate_question import *
from game_feedback import *
from string import ascii_letters, digits 
import pygame 

pygame.mixer.init()


STARTING_DATA = {
    "levels":{
        i:{
            "high_score":0,
            "questions":{
                "correct":0,
                "answered":0
            },
            "games_played":0,
            "time_played":0
        } for i in range(1, 9)
    },
    "settings":{
        "play_music":True,
        "play_sfx":True,
        "ignore_empty_inputs":True,
        "track_statistics":True,
        "track_game_history":True,
        "previous_rounds_to_display":25,
        "stay_logged_in":True
    },
    "game_history":[]
}

QUESTION_TO_GENERATE = {
    1:Level1Question,
    2:Level2Question,
    3:Level3Question,
    4:Level4Question,
    5:Level5Question,
    6:Level6Question,
    7:Level7Question,
    8:Level8Question
}

ALLOW_DUPLICATE_QUESTIONS = {
    1:True, 
    2:False, 
    3:False,
    4:False,
    5:False,
    6:False,
    7:False,
    8:False
}

GAME_FEEDBACK_MESSAGES = {
    1:Level1Feedback,
    2:Level2Feedback,
    3:Level3Feedback,
    4:Level4Feedback,
    5:Level5Feedback,
    6:Level6Feedback,
    7:Level7Feedback,
    8:Level8Feedback
}

VALID_USERNAME_CHARACTERS = ascii_letters + digits + "_"

GREEN = "#19c251"
BLUE = "#03a1fc"

MAIN_MENU_MUSIC = pygame.mixer.Sound("sounds/main_menu.mp3")


