class Rectangle:


    def __init__(self, length, width):
        self.length = length
        self.width = width
        self.area = self.length * self.width
        self.perimeter = (self.length + self.width) * 2


class Square(Rectangle):


    def __init__(self, side_length):
        super().__init__(side_length, side_length)


class Triangle:


    def __init__(self, base, perpendicular_height):
        self.base = base 
        self.height = perpendicular_height
        self.area = 0.5 * self.base * self.height



class Cuboid:


    def __init__(self, length, breadth, height):
        self.length = length 
        self.breadth = breadth 
        self.height = height 
        self.volume = self.length * self.breadth * self.height
        self.surface_area = (2 * self.length * self.breadth) + (2 * self.length * self.height) + (2 * self.breadth * self.height)


class Cube(Cuboid):


    def __init__(self, length):
        super().__init__(length, length, length)
