from constants import *
from functions import *
import os 
import json
import datetime 


def keep_logged_in_or_not():
    data = Settings()
    if data.data_file != "temporary_guest_data.txt" and not data.settings["stay_logged_in"]:
        with open("log.txt", "w") as f:
            f.close()


class Data:
    """
    Handles and stores user data 
    """


    def __init__(self, password=""):
        self.password = password
        if not os.path.exists("log.txt"):
            with open("log.txt", "w") as f:
                f.close()
        with open("log.txt") as f:
            self.user = f.read()
        self.data_file = f"accounts/{self.user}.txt" if self.user else "temporary_guest_data.txt"

        if not os.path.exists(self.data_file):
            self.change_to_starting_data()
        self.load_data()
    

    def change_to_starting_data(self):
        with open(self.data_file, "w") as f:
            json.dump({"password":self.password} | STARTING_DATA, f)
    

    def reset_stats(self):
        self.data["levels"] = STARTING_DATA["levels"]
        self.update_data()
    

    def reset_settings(self):
        self.data["settings"] = STARTING_DATA["settings"]
        self.update_data()
    

    def clear_game_history(self):
        self.data["game_history"] = STARTING_DATA["game_history"]
        self.update_data()

    
    def load_data(self):
        with open(self.data_file) as f:
            self.data = json.load(f)

    
    def update_data(self):
        with open(self.data_file, "w") as f:
            json.dump(self.data, f)





class SignUp:
    """
    Performs account creation
    """


    def __init__(self, username, password):
        self.username = username 
        self.password = password
        self.sign_up()
        with open("log.txt", "w") as f:
            f.write(self.username)
    

    def sign_up(self):
        with open(f"accounts/{self.username}.txt", "w") as f:
            json.dump({
                "password":self.password,
                "date_created": datetime.datetime.now().strftime("%d-%m-%y")
            } | STARTING_DATA, f)





class LevelStatistics(Data):
    """
    Child class of Data class.
    Makes handling a particular level's data easier and more concise. 
    Can still handle normal data not simplified.
    """


    def __init__(self, level):
        super().__init__()
        self.level = level 
        self.level_data = {
            "high_score":self.data["levels"][str(self.level)]["high_score"],
            "correct":self.data["levels"][str(self.level)]["questions"]["correct"],
            "answered":self.data["levels"][str(self.level)]["questions"]["answered"],
            "games_played":self.data["levels"][str(self.level)]["games_played"],
            "time_played":self.data["levels"][str(self.level)]["time_played"]
        }
        self.level_data["accuracy"] = calculate_accuracy(self.level_data["correct"], self.level_data["answered"])
    

    def update_data(self):
        self.data["levels"][str(self.level)]["high_score"] = self.level_data["high_score"]
        self.data["levels"][str(self.level)]["questions"]["correct"] = self.level_data["correct"]
        self.data["levels"][str(self.level)]["questions"]["answered"] = self.level_data["answered"]
        self.data["levels"][str(self.level)]["games_played"] = self.level_data["games_played"]
        self.data["levels"][str(self.level)]["time_played"] = self.level_data["time_played"]
        return super().update_data()





class Settings(Data):
    """
    Child class of Data class.
    Makes handling settings data easier and more concise.
    Can still handle normal data not simplified.
    """


    def __init__(self):
        super().__init__()
        self.settings = self.data["settings"]
    

    def update_data(self):
        self.data["settings"] = self.settings
        return super().update_data()





class GameHistory(Data):
    """
    Child class of Data class.
    Makes handling game history data easier and more concise.
    Can still handle normal data not simplified.
    """


    def __init__(self):
        super().__init__()
        self.game_history = self.data["game_history"]
    

    def update_data(self):
        self.data["game_history"] = self.game_history
        return super().update_data()