from random import choice 
import datetime
import os 
from greetings import *


def attempt_convert_to_integer(number: float):
    return int(number) if int(number) == number else number


def calculate_accuracy(correct: int, answered: int):
    return attempt_convert_to_integer((correct/answered) * 100) if answered > 0 else 0


def state_normal_or_disabled(boolean: bool, reverse=False):
    return ("normal" if boolean else "disabled") if not reverse else ("disabled" if boolean else "normal")


def random_positive_or_negative(n):
    return choice((n, n*-1))


def delete_guest_data():
    if os.path.exists("temporary_guest_data.txt"):
        os.remove("temporary_guest_data.txt")


def format_time_played(seconds: float):
    seconds = int(seconds)
    hours = seconds // 3600 
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    if hours:
        return f"{hours}h {minutes}m {seconds}s"
    elif minutes:
        return f"{minutes}m {seconds}s"
    return f"{seconds}s"



def select_appropriate_greeting():
    hour = datetime.datetime.now().hour 
    if 3 < hour <= 12:
        return MorningGreeting().greeting
    elif 12 < hour <= 16:
        return AfternoonGreeting().greeting
    elif 16 < hour <= 21:
        return EveningGreeting().greeting
    return NightGreeting().greeting

    
