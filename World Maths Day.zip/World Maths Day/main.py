# Standard / third-party libraries 
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
from timeit import default_timer
import datetime
import pygame
import os 
import webbrowser


# Own modules
from constants import *
from generate_question import *
from data import *
from functions import *


def remove_all_widgets(root: Tk):
    for widget in root.winfo_children():
        if isinstance(widget, Menu):
            widget.destroy()
        else:
            widget.grid_forget()


def clear_entry(entry: Entry):
    entry.delete(0, END)


def play_sound_one_at_a_time(file_location: str):
    pygame.mixer.music.load(file_location)
    pygame.mixer.music.play()




class MainMenu:
    """
    Main menu of application 
    """


    def __init__(self, root:Tk=Tk()):
        self.root = root 
        self.root.title("Maths Challenge")
        self.root.resizable(False, False)
        self.root.iconbitmap("images/math.ico")
        self.settings = Settings()

        self.check_logged_in()
        self.create_menu()

        self.title_label = Label(self.root, font=("Gadugi", 50, "bold"), text="Maths Challenge")
        self.logged_in_label = Label(self.root, font=("Gadugi", 10),
        text=f"Currently logged in as: {self.logged_in}" if self.logged_in else "Currently playing as guest - any data will be lost upon exiting, signing up or logging in")
        self.select_level_label = Label(self.root, font=("Gadugi", 25, "bold"), text="Select Level")
        self.display_levels()
        self.start_music()

        self.title_label.grid(row=0, column=0, padx=100, pady=15)
        self.logged_in_label.grid(row=1, column=0, padx=100)
        self.select_level_label.grid(row=2, column=0, padx=100, pady=15)
        self.levels.grid(row=3, column=0, padx=50, pady=15)

        self.root.mainloop()
    

    def create_menu(self):
        self.menu_bar = Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu = Menu(self.menu_bar, tearoff=False, font=("Gadugi", 12))
        self.menu_bar.add_cascade(label="Menu", menu=self.menu)
        self.menu.add_command(label="Account", command=self.open_account, state=state_normal_or_disabled(self.logged_in))
        self.menu.add_command(label="Settings", command=self.open_settings)
        self.menu.add_command(label="Statistics", command=self.open_statistics)
        self.menu.add_command(label="Game history", command=self.open_game_history)
        self.menu.add_command(label="Sign up", command=self.open_sign_up, state=state_normal_or_disabled(self.logged_in, reverse=True))
        self.menu.add_command(label="Log in", command=self.open_log_in, state=state_normal_or_disabled(self.logged_in, reverse=True))
        self.menu.add_command(label="Log out", command=self.confirm_log_out, state=state_normal_or_disabled(self.logged_in))
        self.menu.add_command(label="Website", command=self.open_website)
        self.menu.add_command(label="Tutorial", command=self.open_tutorial)
        self.menu.add_command(label="Tips", command=self.open_tips)
        self.menu.add_command(label="Credits", command=self.open_credits)
    

    def display_levels(self):
        self.level = IntVar(self.root, 0)
        self.levels = LabelFrame(self.root, padx=25, pady=25)
        for i in range(1, 9):
            Radiobutton(self.levels, font=("Gadugi", 25), text=i, variable=self.level, value=i, border=5, indicatoron=False, width=3, height=1, command=self.select_level).grid(row=0, column=i-1, padx=10, pady=15)
        self.level_stats_label = Label(self.root, font=("Gadugi", 12))
        self.start_button = Button(self.root, font=("Gadugi", 20), text="Start", border=5, padx=25, command=self.start_game)
    

    def start_music(self):
        if self.settings.settings["play_music"]:
            MAIN_MENU_MUSIC.play(-1)


    def check_logged_in(self):
        with open("log.txt") as f:
            self.logged_in = f.read()


    def prepare_leave_main_menu(self):
        remove_all_widgets(self.root)
        MAIN_MENU_MUSIC.stop()

    
    def start_game(self):
        self.prepare_leave_main_menu()
        return Game(self.level.get(), self.root)
    

    def select_level(self):
        self.data = LevelStatistics(self.level.get())
        self.level_stats_label.config(text=f"""High Score: {self.data.level_data["high_score"]}
Correct answers: {self.data.level_data["correct"]}
Total answers: {self.data.level_data["answered"]}
Accuracy: {round(self.data.level_data["accuracy"], 2)}%
        """)
        self.level_stats_label.grid(row=4, column=0, padx=100, pady=15)
        self.start_button.grid(row=5, column=0, padx=100, pady=15)
    

    def open_settings(self):
        self.prepare_leave_main_menu()
        return SettingsWindow(self.root)
    

    def open_sign_up(self):
        self.prepare_leave_main_menu()
        return SignUpWindow(self.root)
    

    def open_log_in(self):
        self.prepare_leave_main_menu()
        return LoginWindow(self.root)
    

    def confirm_log_out(self):
        if messagebox.askyesnocancel(title="Confirm log out", message="Are you sure you would like to log out of your account?"):
            self.log_out()
    

    def log_out(self):
        with open("log.txt", "w") as f:
            f.close()
        messagebox.showinfo(title="Success", message="Successfully logged out")
        self.prepare_leave_main_menu()
        return MainMenu(self.root)
    

    def open_account(self):
        self.prepare_leave_main_menu()
        return AccountWindow(self.logged_in, self.root)
    

    def open_statistics(self):
        self.prepare_leave_main_menu()
        return StatisticsWindow(self.root)
    

    def open_game_history(self):
        self.prepare_leave_main_menu()
        return GameHistoryWindow(self.root)

    
    def open_website(self):
        webbrowser.open(os.path.realpath(r"website\index.html"))

    
    def open_tutorial(self):
        webbrowser.open(os.path.realpath(r"website\tutorial.html"))
    

    def open_tips(self):
        webbrowser.open(os.path.realpath(r"website\tips.html"))
    

    def open_credits(self):
        webbrowser.open(os.path.realpath(r"website\credits.html"))





class Game:
    """
    The game itself, from countdown to finish
    """


    def __init__(self, level: int, root: Tk):
        self.root = root 
        self.level = level 
        self.root.title(f"Level {self.level}")
        self.settings = Settings()

        self.three_two_one_go()
        self.timer_label = Label(self.root, font=("Gadugi", 25))

        self.score = 0
        self.lives = 3
        self.results = []
        self.score_label = Label(self.root, font=("Gadugi", 12), text=f"Score: {self.score}")
        self.lives_label = Label(self.root, font=("Gadugi", 12), text=f"Lives:")
        self.add_hearts()

        self.end_game_button = Button(self.root, font=("Gadugi", 12), border=5, text="End Game", command=self.end_game_early)

        self.question_label = Label(self.root, width=20, height=2, font=("Gadugi", 50))
        self.answer_variable = StringVar(self.root)
        self.answer_variable.trace("w", lambda name, index, mode, sv=self.answer_variable: self.valid_character_check())
        self.answer_entry = Entry(self.root, font=("Gadugi", 50), width=4, textvariable=self.answer_variable)
        self.answer_entry.focus()

        self.timer_label.grid(row=0, column=0, padx=25, pady=25, sticky=NW)
        self.score_label.grid(row=0, column=1, padx=25, pady=25, sticky=NW)
        self.lives_label.grid(row=0, column=2, padx=25, pady=25, sticky=NW)
        self.heart.grid(row=0, column=3, pady=25, sticky=NW)
        self.end_game_button.grid(row=0, column=4, padx=25, pady=25, sticky=NW)
        self.question_label.grid(row=1, column=0, columnspan=3, padx=25, pady=25)
        self.answer_entry.grid(row=1, column=3, padx=25, pady=25)

        self.ask_question()
        self.root.bind("<Return>", self.answer_input)

        self.time_started = datetime.datetime.now().strftime("%d/%m/%y %H:%M:%S")
        self.countdown(range(60, 0, -1), self.timer_label)
        self.timer = default_timer()
        while not self.finished_countdown:
            self.root.update()

        self.proceed_to_game_over()
    

    def three_two_one_go(self):
        self.countdown_label = Label(self.root, font=("Gadugi", 100))
        self.countdown_label.grid(row=0, column=0, padx=100, pady=100)
        self.countdown((3,2,1,"GO!"), self.countdown_label, 
        ("sounds/countdown.mid","sounds/countdown.mid","sounds/countdown.mid","sounds/go.mid") if self.settings.settings["play_sfx"] else [])
        while not self.finished_countdown:
            self.root.update()
        self.countdown_label.grid_forget()

    
    def add_hearts(self):
        self.heart = Frame(self.root)
        self.heart_image = ImageTk.PhotoImage(Image.open("images/heart.png"))
        self.hearts = [Label(self.heart, image=self.heart_image) for i in range(3)]
        for i, heart in enumerate(self.hearts):
            heart.grid(row=0, column=i)


    def countdown(self, values: tuple, widget, sounds=[], interval:int=1000):
        self.finished_countdown = False
        self.increment_countdown_value(values[::-1], widget, sounds[::-1], len(values)-1, interval)
    

    def increment_countdown_value(self, values, widget, sounds, index, interval):
        self.finished_countdown = index < 0
        if not self.finished_countdown:
            widget.config(text=values[index])
            if sounds:
                try:
                    play_sound_one_at_a_time(sounds[index])
                except IndexError:
                    pass 
            self.countdown_event = self.root.after(interval, lambda: self.increment_countdown_value(values, widget, sounds, index-1, interval))
    

    def valid_character_check(self):
        answer_variable = self.answer_variable.get()
        if answer_variable:
            character = answer_variable[-1]
            if character not in "0123456789.-" or answer_variable.count(".") > 1 or (character == "-" and len(answer_variable) > 1):
                self.answer_variable.set(answer_variable[:-1])

        
    def generate_question(self, duplicate_question_allowed=True):
        question, answer = QUESTION_TO_GENERATE[self.level]().result
        if self.results:
            if duplicate_question_allowed:
                previous_question = self.results[-1]["question"]
                while question == previous_question:
                    question, answer = QUESTION_TO_GENERATE[self.level]().result
            else:
                completed_questions = [result["question"] for result in self.results]
                while question in completed_questions:
                    question, answer = QUESTION_TO_GENERATE[self.level]().result
        return question, answer

    
    def ask_question(self):
        self.question, self.correct_answer = self.generate_question(duplicate_question_allowed=ALLOW_DUPLICATE_QUESTIONS[self.level])
        self.question_label.config(text=self.question)
    

    def check_answer(self):
        self.answer = self.answer_entry.get()
        if not self.settings.settings["ignore_empty_inputs"] and self.answer == "":
            return False
        if self.answer not in ("", "."):
            return float(self.answer) == self.correct_answer if not isinstance(self.correct_answer, tuple) else float(self.answer) in self.correct_answer
        

    def answer_input(self, input):
        is_correct = self.check_answer()
        if is_correct is not None:
            self.results.append({
                "question":self.question,
                "answer":attempt_convert_to_integer(float(self.answer)) if self.answer else "",
                "correct_answer":self.correct_answer,
                "is_correct":is_correct
            })
            if is_correct:
                self.correct_answer_action()
            else:
                self.incorrect_answer_action()
            clear_entry(self.answer_entry)
            self.ask_question()
    

    def correct_answer_action(self):
        self.score += 1
        self.score_label.config(text=f"Score: {self.score}")
    

    def incorrect_answer_action(self):
        self.lives -= 1
        if self.lives <= 0:
            return self.end_game_early()
        self.hearts.pop().grid_forget()
    

    def end_game_early(self):
        self.root.after_cancel(self.countdown_event)
        return self.proceed_to_game_over()


    def proceed_to_game_over(self):
        time_elapsed = default_timer()-self.timer
        remove_all_widgets(self.root)
        self.root.unbind("<Return>")
        return GameOver(self.score, self.level, self.lives, self.results, self.time_started, time_elapsed, self.root)





class GameOver:
    """
    After the game ends, whether by timeout or out of lives, or if user ended game early. 
    """


    def __init__(self, score: int, level: int, lives: int, results: list, time_started: str, time_played: float, root: Tk):
        self.score = score 
        self.level = level 
        self.lives = lives 
        self.results = results
        self.time_started = time_started
        self.time_played = time_played
        self.root = root 
        self.root.title(f"Level {self.level} - Game Over")
        self.level_data = LevelStatistics(self.level)
        self.settings = Settings()

        self.is_high_score = self.score > self.level_data.level_data["high_score"] and self.settings.settings["track_statistics"]
        if self.settings.settings["track_statistics"]:
            self.update_stats()
        if self.settings.settings["track_game_history"]:
            self.update_game_history()

        self.game_over_message_label = Label(self.root, font=("Gadugi", 35, "bold"), text="Game Over")
        self.final_score_label = Label(self.root, font=("Gadugi", 25), text=f"Final score: {self.score} {'(High Score!)' if self.is_high_score else ''}", fg=(GREEN if self.is_high_score else BLUE))
        self.feedback_label = Label(self.root, font=("Gadugi", 15), text=GAME_FEEDBACK_MESSAGES[self.level](self.score).message, fg=BLUE)
        self.accuracy_label = Label(self.root, font=("Gadugi", 15), text=f"Accuracy: {round(calculate_accuracy(self.score, self.score+(3-lives)), 2)}%")

        if self.score or self.lives < 3:
            self.create_results_listbox()

        self.options = LabelFrame(self.root)
        self.play_again_button = Button(self.options, font=("Gadugi", 15), text="Play Again", border=5, command=self.play_again)
        self.return_to_main_menu_button = Button(self.options, font=("Gadugi", 15), text="Main Menu", border=5, command=self.return_to_main_menu)

        self.game_over_message_label.grid(row=0, column=0, padx=100, pady=15)
        self.final_score_label.grid(row=1, column=0, padx=100, pady=15)
        self.feedback_label.grid(row=2, column=0, padx=50, pady=15)
        self.accuracy_label.grid(row=3, column=0, padx=100, pady=15)

        self.options.grid(row=5, column=0, padx=100, pady=25)
        self.play_again_button.grid(row=0, column=0, padx=25, pady=25)
        self.return_to_main_menu_button.grid(row=0, column=1, padx=25, pady=25)
    

    def create_results_listbox(self):
        results = StringVar(self.root, value=[
            f"{i}. Question: {result['question']} /// Your Answer: {result['answer']} {'✓' if result['is_correct'] else '✗'}\
{'/// Correct Answer: ' + str(attempt_convert_to_integer(result['correct_answer']))  if not result['is_correct'] else ''}"
            for i, result in enumerate(self.results, start=1)
        ])
        self.results_listbox = Listbox(self.root, listvariable=results, font=("Gadugi", 12), width=75, height=min(len(self.results), 5))
        self.results_listbox.grid(row=4, column=0, padx=25, pady=25)
    

    def update_stats(self):
        self.level_data.level_data["games_played"] += 1
        self.level_data.level_data["correct"] += self.score 
        self.level_data.level_data["answered"] += self.score + 3-self.lives
        self.level_data.level_data["time_played"] += self.time_played
        if self.is_high_score:
            self.level_data.level_data["high_score"] = self.score 
        self.level_data.update_data()
    

    def update_game_history(self):
        self.game_history = GameHistory()
        self.game_history.game_history.insert(0, {
            "level":self.level,
            "score":self.score,
            "lives":self.lives,
            "time":self.time_started,
            "accuracy":calculate_accuracy(self.score, self.score + 3-self.lives),
            "results":self.results
        })
        if len(self.game_history.game_history) > 50:
            self.game_history.game_history.pop()
        self.game_history.update_data()
    

    def play_again(self):
        remove_all_widgets(self.root)
        return Game(self.level, self.root)
    

    def return_to_main_menu(self):
        remove_all_widgets(self.root)
        return MainMenu(self.root)





class StatisticsWindow:


    def __init__(self, root: Tk):
        self.root = root 
        self.root.title("Statistics")
        
        self.create_menu()
        self.title_label = Label(self.root, font=("Gadugi", 50, "bold"), text="Statistics")
        self.display_statistics()
        self.reset_stats_button = Button(self.root, font=("Gadugi", 15), text="Reset Stats", border=5, command=self.confirm_reset_stats)

        self.title_label.grid(row=0, column=0, padx=100, pady=25)
        self.stats_table.grid(row=1, column=0, padx=50, pady=25)
        self.reset_stats_button.grid(row=2, column=0, padx=100, pady=25)


    def create_menu(self):
        self.menu_bar = Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu = Menu(self.menu_bar, tearoff=False, font=("Gadugi", 12))
        self.menu_bar.add_cascade(label="Menu", menu=self.menu)
        self.menu.add_command(label="Main menu", command=self.return_to_main_menu)
    

    def display_statistics(self):
        self.stats_table = Frame(self.root)
        for i, column in enumerate(("Level", "Games Played", "Time Played", "High Score", "Correct", "Answered", "Accuracy")):
            Label(self.stats_table, font=("Gadugi", 16, "bold"), text=column).grid(row=0, column=i, padx=25)
        for i in range(1, 9):
            level_data = LevelStatistics(i)
            texts = (i, 
        level_data.level_data["games_played"],
        format_time_played(level_data.level_data["time_played"]),
        level_data.level_data["high_score"], 
        level_data.level_data["correct"], 
        level_data.level_data["answered"], 
        f"{round(level_data.level_data['accuracy'], 2)}%")
            for j, text in enumerate(texts):
                Label(self.stats_table, font=("Gadugi", 15), text=text).grid(row=i, column=j)
    

    def confirm_reset_stats(self):
        if messagebox.askyesnocancel(title="Confirm reset stats", message="Are you sure you want to reset your stats?\nThis cannot be undone."):
            self.reset_stats()
    

    def reset_stats(self):
        Data().reset_stats()
        messagebox.showinfo(title="Done", message="Stats successfully reset, click OK to continue")
        remove_all_widgets(self.root)
        return StatisticsWindow(self.root)


    def return_to_main_menu(self):
        remove_all_widgets(self.root)
        return MainMenu(self.root)





class SettingsWindow:
    """
    Allows user to modify settings and do certain things, hence this is the settings window 
    """


    def __init__(self, root: Tk):
        self.root = root 
        self.root.title("Settings")
        self.settings = Settings()

        self.create_menu()
        self.title_label = Label(self.root, font=("Gadugi", 35, "bold"), text="Settings")

        self.settings_dict = {
            "play_music":BooleanVar(self.root, self.settings.settings["play_music"]),
            "play_sfx":BooleanVar(self.root, self.settings.settings["play_sfx"]),
            "ignore_empty_inputs":BooleanVar(self.root, self.settings.settings["ignore_empty_inputs"]),
            "track_statistics":BooleanVar(self.root, self.settings.settings["track_statistics"]),
            "track_game_history":BooleanVar(self.root, self.settings.settings["track_game_history"]),
            "stay_logged_in":BooleanVar(self.root, self.settings.settings["stay_logged_in"]),
            "previous_rounds_to_display":IntVar(self.root, self.settings.settings["previous_rounds_to_display"])
        }
        self.display_settings()

        self.reset_settings_button = Button(self.root, font=("Gadugi", 12), border=5, text="Reset to default settings", command=self.confirm_reset_settings)

        self.title_label.grid(row=0, column=0, padx=100, pady=25)
        self.settings_grid.grid(row=1, column=0, padx=100, pady=25)
        self.reset_settings_button.grid(row=2, column=0, padx=100, pady=25)


    def create_menu(self):
        self.menu_bar = Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu = Menu(self.menu_bar, tearoff=False, font=("Gadugi", 12))
        self.menu_bar.add_cascade(label="Menu", menu=self.menu)
        self.menu.add_command(label="Main menu", command=self.return_to_main_menu)


    def display_settings(self):
        self.settings_grid = Frame(self.root)
        for i, category in enumerate((
            "Music", 
            "Sound Effects", 
            "Ignore empty inputs in game", 
            "Track statistics", 
            "Track game history",
            "Stay logged in when application closed",
            "Number of previous rounds to display in history"
        )):
            if not (i == 5 and self.settings.data_file == "temporary_guest_data.txt"):
                Label(self.settings_grid, font=("Gadugi", 12), text=category).grid(row=i, column=0, padx=25, pady=5, sticky=E)
        frames = [Frame(self.settings_grid) for i in range(len(self.settings_dict))]
        settings = (
            (
                Radiobutton(frames[0], variable=self.settings_dict["play_music"], value=True, font=("Gadugi", 12), text="ON",
                indicatoron=False, command=lambda: self.change_setting("play_music", True)),
                Radiobutton(frames[0],variable=self.settings_dict["play_music"], value=False, font=("Gadugi", 12), text="OFF", 
                indicatoron=False, command=lambda: self.change_setting("play_music", False)),
            ),
            (
                Radiobutton(frames[1], variable=self.settings_dict["play_sfx"], value=True, font=("Gadugi", 12), text="ON",
                indicatoron=False, command=lambda: self.change_setting("play_sfx", True)),
                Radiobutton(frames[1],variable=self.settings_dict["play_sfx"], value=False, font=("Gadugi", 12), text="OFF", 
                indicatoron=False, command=lambda: self.change_setting("play_sfx", False)),
            ),
            (
                Radiobutton(frames[2], variable=self.settings_dict["ignore_empty_inputs"], value=True, font=("Gadugi", 12), text="ON",
                indicatoron=False, command=lambda: self.change_setting("ignore_empty_inputs", True)),
                Radiobutton(frames[2],variable=self.settings_dict["ignore_empty_inputs"], value=False, font=("Gadugi", 12), text="OFF", 
                indicatoron=False, command=lambda: self.change_setting("ignore_empty_inputs", False)),
            ),
            (
                Radiobutton(frames[3], variable=self.settings_dict["track_statistics"], value=True, font=("Gadugi", 12), text="ON",
                indicatoron=False, command=lambda: self.change_setting("track_statistics", True)),
                Radiobutton(frames[3],variable=self.settings_dict["track_statistics"], value=False, font=("Gadugi", 12), text="OFF", 
                indicatoron=False, command=lambda: self.change_setting("track_statistics", False)),
            ),
            (
                Radiobutton(frames[4], variable=self.settings_dict["track_game_history"], value=True, font=("Gadugi", 12), text="ON",
                indicatoron=False, command=lambda: self.change_setting("track_game_history", True)),
                Radiobutton(frames[4],variable=self.settings_dict["track_game_history"], value=False, font=("Gadugi", 12), text="OFF", 
                indicatoron=False, command=lambda: self.change_setting("track_game_history", False)),
            ),
            (
                Radiobutton(frames[5], variable=self.settings_dict["stay_logged_in"], value=True, font=("Gadugi", 12), text="ON",
                indicatoron=False, command=lambda: self.change_setting("stay_logged_in", True)),
                Radiobutton(frames[5],variable=self.settings_dict["stay_logged_in"], value=False, font=("Gadugi", 12), text="OFF", 
                indicatoron=False, command=lambda: self.change_setting("stay_logged_in", False)),
            ),
            (Scale(frames[6], variable=self.settings_dict["previous_rounds_to_display"], from_=0, to=50, sliderlength=25, font=("Gadugi", 12), 
            orient=HORIZONTAL, command=lambda value: self.change_setting("previous_rounds_to_display", int(value)), length=250),)
        )
        for i, setting in enumerate(settings):
            if not (i == 5 and self.settings.data_file == "temporary_guest_data.txt"):
                for j, choice in enumerate(setting):
                    choice.grid(row=0, column=j, padx=5)
                frames[i].grid(row=i, column=1, padx=25, sticky=W)


    def change_setting(self, setting, new_value):
        self.settings.settings[setting] = new_value
        self.settings.update_data()
    

    def confirm_reset_settings(self):
        if messagebox.askyesnocancel(title="Confirm reset settings", message="Are you sure you want to reset your settings to default?\nThis cannot be undone."):
            self.reset_settings()
    

    def reset_settings(self):
        Data().reset_settings()
        messagebox.showinfo(title="Done", message="Settings successfully reset to default, click OK to continue")
        remove_all_widgets(self.root)
        return SettingsWindow(self.root)


    def return_to_main_menu(self):
        remove_all_widgets(self.root)
        return MainMenu(self.root)





class GameHistoryWindow:
    """
    Displays history of games, including their statistics and questions.
    """


    def __init__(self, root: Tk):
        self.root = root 
        self.root.title("Game history")
        self.settings = Settings()
        self.game_history = GameHistory()
        self.create_menu()
        self.title_label = Label(self.root, font=("Gadugi", 30, "bold"), text="Game history")
        self.game_info = Frame(self.root)
        if self.settings.settings["previous_rounds_to_display"] == 0 or not self.game_history.game_history:
            self.message_label = Label(self.root, font=("Gadugi", 25), 
            text=("No history!" if not self.game_history.game_history else "Setting of number rounds to display in history set to 0"))
            self.message_label.grid(row=1, column=0, padx=100, pady=25)
        else:
            self.create_game_history_listbox()
            self.clear_game_history_button = Button(self.root, font=("Gadugi", 12), border=5, text="Clear game history", command=self.confirm_clear_game_history)
            self.clear_game_history_button.grid(row=3, column=0, padx=100, pady=25)

        self.title_label.grid(row=0, column=0, padx=100, pady=15)


    def create_menu(self):
        self.menu_bar = Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu = Menu(self.menu_bar, tearoff=False, font=("Gadugi", 12))
        self.menu_bar.add_cascade(label="Menu", menu=self.menu)
        self.menu.add_command(label="Main menu", command=self.return_to_main_menu)
    

    def create_game_history_listbox(self):
        games = StringVar(self.root, value=[
            f"Level {game['level']} /// Score: {game['score']} /// Date/Time: {game['time']}" 
            for game in self.game_history.game_history[:self.settings.settings["previous_rounds_to_display"]]
        ])
        self.game_history_listbox = Listbox(self.root, listvariable=games, font=("Gadugi", 10), width=50, 
        height=min(min(len(self.game_history.game_history), self.settings.settings["previous_rounds_to_display"]), 8))
        self.game_history_listbox.bind("<<ListboxSelect>>", 
        lambda input: self.display_game_info(i:=self.game_history_listbox.curselection()[0], self.game_history.game_history[i]))
        self.game_history_listbox.grid(row=1, column=0, padx=100, pady=15)
    

    def display_game_info(self, index, game):
        self.game_info.destroy()
        self.game_info = Frame(self.root)
        for i, category in enumerate(("Level:", "Score:", "Accuracy:", "Lives left:", "Time started:")):
            Label(self.game_info, font=("Gadugi", 12, "bold"), text=category).grid(row=i, column=0, padx=5, sticky=E)
        for i, value in enumerate((game["level"], game["score"], f"{round(game['accuracy'], 2)}%", game["lives"], game["time"])):
            Label(self.game_info, font=("Gadugi", 12), text=value).grid(row=i, column=1, padx=5, sticky=W)
        if game["results"]:
            self.create_results_listbox(game["results"])
        self.delete_game_button = Button(self.game_info, font=("Gadugi", 12), text="Delete game info", border=5, command=lambda: self.confirm_delete_game_info(index))
        self.delete_game_button.grid(row=20, column=0, columnspan=2, padx=5)
        self.game_info.grid(row=2, column=0, padx=50)


    def create_results_listbox(self, results):
        results_variable = StringVar(self.root, value=[
            f"{i}. Question: {result['question']} /// Your Answer: {result['answer']} {'✓' if result['is_correct'] else '✗'}\
{'/// Correct Answer: ' + str(attempt_convert_to_integer(result['correct_answer']))  if not result['is_correct'] else ''}"
            for i, result in enumerate(results, start=1)
        ])
        self.results_listbox = Listbox(self.game_info, listvariable=results_variable, font=("Gadugi", 8), width=75, height=min(len(results), 5))
        self.results_listbox.grid(row=10, column=0, columnspan=2, pady=15)
    

    def confirm_delete_game_info(self, index):
        if messagebox.askyesnocancel(title="Confirm delete game info", message="Are you sure you want to delete this game info?\nThis cannot be undone."):
            self.delete_game_info(index)
    

    def delete_game_info(self, index):
        self.game_history.game_history.pop(index)
        self.game_history.update_data()
        self.game_history_listbox.delete(index, index)
        remove_all_widgets(self.root)
        self.game_history_listbox.unbind("<<ListboxSelect>>")
        return GameHistoryWindow(self.root)


    def confirm_clear_game_history(self):
        if messagebox.askyesnocancel(title="Confirm clear game history", message="Are you sure you want to clear your game history?\nThis cannot be undone."):
            self.clear_game_history()
    

    def clear_game_history(self):
        Data().clear_game_history()
        messagebox.showinfo(title="Done", message="Game history successfully cleared, click OK to continue")
        remove_all_widgets(self.root)
        self.game_history_listbox.unbind("<<ListboxSelect>>")
        return GameHistoryWindow(self.root)


    def return_to_main_menu(self):
        remove_all_widgets(self.root)
        try:
            self.game_history_listbox.unbind("<<ListboxSelect>>")
        except AttributeError:
            pass
        return MainMenu(self.root)





class SignUpWindow:
    """
    Allows user to create new account to play and save data.
    """
    

    def __init__(self, root: Tk):
        self.root = root 
        self.root.title("Sign up"),
        self.create_menu()

        self.title_label = Label(self.root, font=("Gadugi", 40, "bold"), text="Sign Up")
        self.credentials_criteria = Label(self.root, font=("Gadugi", 10), text="""Username:
    • Must be 4 - 20 characters long (inclusive)
    • Only English letters (Aa-Zz), numbers (0-9) and underscore (_), so no spaces
    • Not case sensitive

Password:
    • Must be 6 - 64 characters long (inclusive) and strong
    • Case sensitive""", justify=LEFT)
        self.create_credentials_widgets()
        self.sign_up_button = Button(self.root, font=("Gadugi", 20), text="Sign up!", border=5, command=self.attempt_sign_up)

        self.title_label.grid(row=0, column=0, padx=100, pady=25)
        self.credentials_criteria.grid(row=1, column=0, padx=100)
        self.credentials.grid(row=2, column=0, padx=100, pady=25)
        self.sign_up_button.grid(row=3, column=0, padx=100, pady=15)
    

    def create_menu(self):
        self.menu_bar = Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu = Menu(self.menu_bar, tearoff=False, font=("Gadugi", 12))
        self.menu_bar.add_cascade(label="Menu", menu=self.menu)
        self.menu.add_command(label="Main menu", command=self.return_to_main_menu)
    

    def create_credentials_widgets(self):
        self.credentials = Frame(self.root)
        self.credential_entries = (
            Entry(self.credentials, font=("Gadugi", 20)),
            Entry(self.credentials, font=("Gadugi", 20), show="•"),
            Entry(self.credentials, font=("Gadugi", 20), show="•"),
        )
        for i, category in enumerate(("Username:", "Password:", "Confirm Password:")):
            Label(self.credentials, font=("Gadugi", 20), text=category).grid(row=i, column=0, padx=25, pady=15, sticky=E)
            self.credential_entries[i].grid(row=i, column=1)
    

    def attempt_sign_up(self):
        self.username, self.password, self.confirm_password = [entry.get() for entry in self.credential_entries]
        self.validate_credentials()
    

    def validate_credentials(self):
        self.problems = []
        self.check_username()
        self.check_password()
        if self.problems:
            return messagebox.showerror(title="Invalid signup", message="The following issues were detected:\n\n" + "\n".join(map(lambda x: "• " + x, self.problems)))
        self.confirm_sign_up()
    

    def check_username(self):
        if (username_length:=len(self.username)) < 4:
            self.problems.append(f"Username too short - current length: {username_length}, minimum: 4")
        elif username_length > 20:
            self.problems.append(f"Username too long - current length: {username_length}, maximum: 20")
        for character in self.username:
            if character not in VALID_USERNAME_CHARACTERS:
                self.problems.append(f"Invalid characters in username... remember only English letters, numbers 0-9 and _")
                break 
        if os.path.exists(f"accounts/{self.username}.txt"):
            self.problems.append("Sorry... username already taken")
    

    def check_password(self):
        if (password_length:=len(self.password)) < 6:
            self.problems.append(f"Password too short - current length: {password_length}, minimum: 6")
        elif password_length > 64:
            self.problems.append(f"Password too long - current length: {password_length}, maximum: 64")
        if self.confirm_password != self.password:
            self.problems.append("Password and password confirmation do not match")
    

    def confirm_sign_up(self):
        if messagebox.askyesnocancel(title="Confirm sign up", message="Are you sure you would like to create this new account?"):
            self.create_new_account()


    def create_new_account(self):
        with open("log.txt", "w") as f:
            f.write(self.username)
        SignUp(self.username, self.password)
        messagebox.showinfo(title="Success", message=f"Successfully made new account: {self.username}\n\nEnjoy :D")
        remove_all_widgets(self.root)
        delete_guest_data()
        return MainMenu(self.root)
        

    def return_to_main_menu(self):
        remove_all_widgets(self.root)
        return MainMenu(self.root)





class LoginWindow:
    """
    Allows user to login and access save data.
    """

    
    def __init__(self, root: Tk):
        self.root = root 
        self.root.title("Login")
        self.create_menu()

        self.title_label = Label(self.root, font=("Gadugi", 50, "bold"), text="Login")
        self.login_guidance_label = Label(self.root, font=("Gadugi", 12), text="Note: username is not case sensitive, but password is.")
        self.create_credentials_widgets()
        self.login_button = Button(self.root, font=("Gadugi", 20), text="Log in!", border=5, command=self.attempt_log_in)

        self.title_label.grid(row=0, column=0, padx=100, pady=25)
        self.login_guidance_label.grid(row=1, column=0, padx=100)
        self.credentials.grid(row=2, column=0, padx=100, pady=25)
        self.login_button.grid(row=3, column=0, padx=100, pady=25)


    def create_menu(self):
        self.menu_bar = Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu = Menu(self.menu_bar, tearoff=False, font=("Gadugi", 12))
        self.menu_bar.add_cascade(label="Menu", menu=self.menu)
        self.menu.add_command(label="Main menu", command=self.return_to_main_menu)


    def create_credentials_widgets(self):
        self.credentials = Frame(self.root)
        self.credential_entries = (
            Entry(self.credentials, font=("Gadugi", 20)),
            Entry(self.credentials, font=("Gadugi", 20), show="•"),
        )
        for i, category in enumerate(("Username:", "Password:")):
            Label(self.credentials, font=("Gadugi", 20), text=category).grid(row=i, column=0, padx=25, pady=15, sticky=E)
            self.credential_entries[i].grid(row=i, column=1)
    

    def attempt_log_in(self):
        self.username, self.password = [entry.get() for entry in self.credential_entries]
        if not os.path.exists(f"accounts/{self.username}.txt"):
            return messagebox.showerror(title="Login failed", message="Incorrect username or password")
        with open(f"accounts/{self.username}.txt") as f:
            if self.password != json.load(f)["password"]:
                return messagebox.showerror(title="Login failed", message="Incorrect username or password")
        self.log_in()
    

    def log_in(self):
        with open("log.txt", "w") as f:
            f.write(self.username)
        messagebox.showinfo(title="Login successful", message=f"Successfully logged in! Welcome back, {self.username}")
        remove_all_widgets(self.root)
        delete_guest_data()
        return MainMenu(self.root)
    

    def return_to_main_menu(self):
        remove_all_widgets(self.root)
        return MainMenu(self.root)





class AccountWindow:
    """
    User's account window, greets user, provides shortcuts to settings, statistics etc. 
    """
    

    def __init__(self, username: str, root: Tk):
        self.username = username 
        self.root = root 
        self.root.title(self.username)
        self.data = Data()

        self.create_menu()

        self.title_label = Label(self.root, font=("Gadugi", 50, "bold"), text="Account")
        self.greeting_label = Label(self.root, font=("Gadugi", 15), text=select_appropriate_greeting())
        self.username_label = Label(self.root, font=("Gadugi", 20), text=self.username, fg=BLUE)
        self.date_joined_label = Label(self.root, font=("Gadugi", 12), text=f"Account created: {self.data.data['date_created']}")
        self.display_options()

        self.title_label.grid(row=0, column=0, padx=100, pady=15)
        self.greeting_label.grid(row=1, column=0, padx=50, pady=15)
        self.username_label.grid(row=2, column=0, padx=50, pady=15)
        self.date_joined_label.grid(row=3, column=0, padx=50, pady=15)
        self.options.grid(row=4, column=0, padx=50, pady=15)
    


    def create_menu(self):
        self.menu_bar = Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu = Menu(self.menu_bar, tearoff=False, font=("Gadugi", 12))
        self.menu_bar.add_cascade(label="Menu", menu=self.menu)
        self.menu.add_command(label="Main menu", command=self.return_to_main_menu)
    

    def display_options(self):
        self.options = Frame(self.root)
        for i, button in enumerate((
            Button(self.options, font=("Gadugi", 15), border=5, width=15, text="Settings", command=self.open_settings),
            Button(self.options, font=("Gadugi", 15), border=5, width=15, text="Statistics", command=self.open_statistics),
            Button(self.options, font=("Gadugi", 15), border=5, width=15, text="Game History", command=self.open_game_history),
        )):
            button.grid(row=i, column=0, padx=25, pady=2)


    def open_settings(self):
        remove_all_widgets(self.root)
        return SettingsWindow(self.root)


    def open_statistics(self):
        remove_all_widgets(self.root)
        return StatisticsWindow(self.root)
    

    def open_game_history(self):
        remove_all_widgets(self.root)
        return GameHistoryWindow(self.root)


    def return_to_main_menu(self):
        remove_all_widgets(self.root)
        return MainMenu(self.root)





if __name__ == "__main__":
    pygame.init()
    pygame.mixer.init()
    delete_guest_data()
    keep_logged_in_or_not()
    MainMenu()
