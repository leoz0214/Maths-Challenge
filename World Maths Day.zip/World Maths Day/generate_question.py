from random import choice, randint, sample
from geometry import *
from functools import reduce
from functions import *


"""
Module which is responsible for generating questions based on level. 
Higher levels are unsurprisingly harder. 
"""



class RandomQuestion:


    def __init__(self, *choices):
        self.result = choice(choices)()
    

    def addition(self, *numbers):
        return " + ".join(map(str, numbers)), sum(numbers)
    

    def subtraction(self, *numbers):
        return " - ".join(map(str, numbers)), reduce(lambda x=0, y=0: x-y, numbers)
    

    def multiplication(self, *numbers):
        return " x ".join(map(str, numbers)), reduce(lambda x=0, y=1: x*y, numbers)
    

    def division(self, *numbers):
        return " ÷ ".join(map(str, numbers)), round(reduce(lambda x=0, y=1: x/y, numbers), 8)
    

    def exponentiation(self, base, power):
        if power in (2, 3, 4):
            return f"{base}{'²' if power == 2 else '³' if power == 3 else '⁴'}", round(base ** power, 8)
    

    def square_root(self, number):
        return f"√{number}", (round(number**0.5, 8), -round(number**0.5, 8))
    

    def cube_root(self, number):
        return f"∛{number}", round(number**(1/3), 8)
    

    def bidmas(self, string: str):
        return string, eval(string.replace("x", "*"))
    

    def fraction_to_decimal(self, numerator, denominator):
        return f"{numerator}/{denominator} to decimal", round(numerator/denominator, 8) 
    

    def fraction_to_percentage(self, numerator, denominator):
        return f"{numerator}/{denominator} = ___ %", round((numerator/denominator)*100, 8)
    

    def decimal_to_percentage(self, decimal):
        return f"{decimal} = ___ %", round(decimal*100, 8)
    

    def percentage_to_decimal(self, percentage):
        return f"{percentage}% to decimal", round(percentage/100, 8)
    

    def sequence(self, start, increment):
        return f"{start}, {round(start+increment, 8)}, {round(start+increment*2, 8)}, _____", round(start+increment*3, 8)
    

    def area(self, shape):
        if isinstance(shape, Square):
            return f"Area of square: \nside {shape.length}", shape.area 
        elif isinstance(shape, Rectangle):
            return f"Area of rectangle: \nlength {shape.length}, width {shape.width}", shape.area 
        elif isinstance(shape, Triangle):
            return f"Area of triangle: \nbase {shape.base}, height {shape.height} ", shape.area 
    

    def perimeter(self, shape):
        if isinstance(shape, Square):
            return f"Perimeter of square: \nside {shape.length}", shape.perimeter
        elif isinstance(shape, Rectangle):
            return f"Perimeter of rectangle: \nlength {shape.length}, width {shape.width}", shape.perimeter
    

    def volume(self, shape):
        if isinstance(shape, Cube):
            return f"Volume of cube: \n{choice(('length', 'breadth', 'height'))} {shape.length}", shape.volume 
        elif isinstance(shape, Cuboid):
            return f"Volume of cuboid: \n{shape.length} by {shape.breadth} by {shape.height}", shape.volume 
    

    def surface_area(self, shape):
        if isinstance(shape, Cube):
            return f"Surface area of cube: \n{choice(('length', 'breadth', 'height'))} {shape.length}", shape.surface_area
        elif isinstance(shape, Cuboid):
            return f"Surface area of cuboid: \n{shape.length} by {shape.breadth} by {shape.height}", shape.surface_area


    def factorial(self, n):
        return f"{n}!", (reduce(lambda x=0, y=1: x*y, range(1, n+1) if n else 1))


class Level1Question(RandomQuestion):


    def __init__(self):
        super().__init__(
            lambda: self.addition(randint(1, 10), randint(1, 10)),
            lambda: self.subtraction(*sorted(sample(range(11, 21), 2), reverse=True))
        )


class Level2Question(RandomQuestion):


    def __init__(self):
        super().__init__(
            lambda: self.addition(randint(11, 20), randint(5, 20)),
            lambda: self.subtraction(*sorted(sample(range(11, 40), 2), reverse=True)),
            lambda: self.multiplication(randint(2, 5), randint(1, 5))
        )


class Level3Question(RandomQuestion):


    def __init__(self):
        super().__init__(
            lambda: self.addition(randint(11, 50), randint(11, 50)),
            lambda: self.subtraction(*sorted(sample(range(11, 100), 2), reverse=True)),
            lambda: self.multiplication(randint(2, 10), randint(2, 10)),
            lambda: self.division((divisor:=randint(2, 10))*randint(2, 10), divisor),
            lambda: self.exponentiation(randint(2, 5), 2)
        )


class Level4Question(RandomQuestion):


    def __init__(self):
        super().__init__(
            lambda: self.addition(randint(11, 100), randint(11, 100)),
            lambda: self.subtraction(*sorted(sample(range(11, 200), 2), reverse=True)),
            lambda: self.multiplication(randint(6, 12), randint(6, 12)),
            lambda: self.division((divisor:=randint(6, 12))*randint(6, 12), divisor),
            lambda: self.exponentiation(randint(3, 12), 2),
            lambda: self.square_root(randint(3, 12)**2),
            choice((
                lambda: self.fraction_to_decimal(denominator=(d:=choice((2, 4, 5, 10, 100))), numerator=randint(1, d-1)),
                lambda: self.fraction_to_percentage(denominator=(d:=choice((2, 4, 5, 10, 100))), numerator=randint(1, d-1)),
                lambda: self.decimal_to_percentage(round(randint(1, 99)/100, 2)),
                lambda: self.percentage_to_decimal(randint(1, 99))
            )),
            lambda: self.sequence(round(randint(25, 75)/10, 1), round(randint(1, 5)/10, 1)*choice((1, -1))),
            choice((
                lambda: self.bidmas(f"({randint(2, 5)} + {randint(1, 5)}) x {randint(2, 10)}"),
                lambda: self.bidmas(f"{randint(11, 50)} + {randint(1, 10)} x {randint(2, 10)}")
            )),
            choice((
                lambda: self.area(Rectangle(*sample(range(5, 11), 2))),
                lambda: self.area(Square(randint(3, 10))),
                lambda: self.perimeter(Rectangle(*sample(range(5, 16), 2))),
                lambda: self.perimeter(Square(randint(5, 21)))
            ))
        )


class Level5Question(RandomQuestion):


    def __init__(self):
        super().__init__(
            choice((
                lambda: self.addition(randint(100, 250), randint(100, 250)),
                lambda: self.addition(randint(16, 33), randint(16, 33), randint(16, 33))
            )),
            choice((
                lambda: self.subtraction(*sorted(sample(range(1, 100), 2))),
                lambda: self.subtraction(*sorted(sample(range(101, 500), 2), reverse=True))
            )),
            choice((
                lambda: self.multiplication(random_positive_or_negative(randint(3, 12)), random_positive_or_negative(randint(3, 12))),
                lambda: self.multiplication(randint(2, 6), randint(2, 6), randint(2, 6))
            )),
            lambda: self.division((divisor:=random_positive_or_negative(randint(6, 12)))*random_positive_or_negative(randint(3, 15)), divisor),
            choice((
                lambda: self.exponentiation(random_positive_or_negative(randint(5, 15)), 2),
                lambda: self.exponentiation(random_positive_or_negative(randint(2, 6)), 3)
            )),
            choice((
                lambda: self.square_root(randint(7, 15)**2),
                lambda: self.cube_root(randint(2, 5)**3)
            )),
            choice((
                lambda: self.fraction_to_decimal(denominator=(d:=choice((4, 5, 10, 20, 25, 50))), numerator=randint(1, d-1)),
                lambda: self.fraction_to_percentage(denominator=(d:=choice((4, 5, 10, 20, 25, 50))), numerator=randint(1, d-1)),
                lambda: self.decimal_to_percentage(round(randint(1, 199)/100, 2)),
                lambda: self.percentage_to_decimal(randint(1, 199))
            )),
            lambda: self.sequence(round(randint(-100, 100)/10, 1), random_positive_or_negative(round(randint(1, 9)/10, 1))),
            choice((
                lambda: self.area(Rectangle(*sample(range(10, 16), 2))),
                lambda: self.area(Triangle(randint(3, 10), randint(3, 10))),
                lambda: self.perimeter(Rectangle(*sample(range(10, 26), 2))),
                lambda: self.perimeter(Square(randint(1, 100)/10))
            )),
            choice((
                lambda: self.volume(Cuboid(*sample(range(2, 7), 3))),
                lambda: self.volume(Cube(randint(3, 6)))
            ))
        )


class Level6Question(RandomQuestion):


    def __init__(self):
        super().__init__(
            choice((
                lambda: self.addition(randint(200, 500), randint(200, 499)),
                lambda: self.addition(randint(50, 100), randint(50, 100), randint(50, 100)),
                lambda: self.addition(random_positive_or_negative(randint(1, 10)), random_positive_or_negative(randint(1, 10)))
            )),
            choice((
                lambda: self.subtraction(*sorted(sample(range(100, 500), 2))),
                lambda: self.subtraction(*sorted(sample(range(201, 999), 2), reverse=True)),
                lambda: self.subtraction(*map(lambda x: random_positive_or_negative(x), sample(range(1, 10), 2)))
            )),
            choice((
                lambda: self.multiplication(random_positive_or_negative(randint(4, 16)), random_positive_or_negative(randint(4, 16))),
                lambda: self.multiplication(randint(3, 7), randint(3, 7), randint(3, 7))
            )),
            lambda: self.division((divisor:=random_positive_or_negative(randint(6, 16)))*random_positive_or_negative(randint(4, 16)), divisor),
            choice((
                lambda: self.exponentiation(random_positive_or_negative(randint(11, 16)), 2),
                lambda: self.exponentiation(random_positive_or_negative(randint(4, 6)), 3)
            )),
            choice((
                lambda: self.square_root(randint(11, 16)**2),
                lambda: self.cube_root(randint(3, 6)**3)
            )),
            choice((
                lambda: self.fraction_to_decimal(denominator=(d:=choice((8, 20, 25))), numerator=randint(1, d-1)),
                lambda: self.fraction_to_percentage(denominator=(d:=choice((8, 20, 25))), numerator=randint(1, d-1)),
                lambda: self.decimal_to_percentage(round(randint(1, 9999)/1000, 3)),
                lambda: self.percentage_to_decimal(round(randint(1, 9999)/10, 1))
            )),
            lambda: self.sequence(round(randint(-100, 100)/10, 1), random_positive_or_negative(round(randint(1, 19)/20, 2))),
            lambda: self.area(Triangle(randint(6, 15), randint(6, 15))),
            choice((
                lambda: self.volume(Cuboid(*sample(range(4, 10), 3))),
                lambda: self.surface_area(Cube(randint(2, 5)))
            ))
        )


class Level7Question(RandomQuestion):


    def __init__(self):
        super().__init__(
            choice((
                lambda: self.addition(randint(1001, 5000), randint(1001, 4999)),
                lambda: self.addition(random_positive_or_negative(randint(1, 100)),random_positive_or_negative(randint(1, 100)),random_positive_or_negative(randint(1, 100)))
            )),
            choice((
                lambda: self.subtraction(*sorted(sample(range(201, 999), 2))),
                lambda: self.subtraction(*map(lambda x: random_positive_or_negative(x/10), sample(range(1, 100), 3)))
            )),
            choice((
                lambda: self.multiplication(random_positive_or_negative(randint(11, 16)), random_positive_or_negative(randint(11, 16))),
                lambda: self.multiplication(random_positive_or_negative(randint(3,8)),random_positive_or_negative(randint(3,8)),random_positive_or_negative(randint(3,8)))
            )),
            lambda: self.division((divisor:=random_positive_or_negative(randint(11, 16)))*random_positive_or_negative(randint(11, 16)), divisor),
            choice((
                lambda: self.exponentiation(random_positive_or_negative(randint(13, 20)), 2),
                lambda: self.exponentiation(random_positive_or_negative(randint(5, 8)), 3)
            )),
            choice((
                lambda: self.square_root(randint(13, 20)**2),
                lambda: self.cube_root(randint(5, 8)**3)
            )),
            lambda: self.area(Triangle(randint(10, 16), randint(10, 16))),
            choice((
                lambda: self.volume(Cuboid(*sample(range(5, 11), 3))),
                lambda: self.surface_area(Cube(randint(3, 6)))
            )),
            lambda: self.factorial(randint(4, 6))
        )


class Level8Question(RandomQuestion):


    def __init__(self):
        super().__init__(
            choice((
                lambda: self.multiplication(random_positive_or_negative(randint(20, 50)), random_positive_or_negative(randint(20, 50))),
                lambda: self.multiplication(random_positive_or_negative(randint(6,9)),random_positive_or_negative(randint(6,9)),random_positive_or_negative(randint(6,9)))
            )),      
            lambda: self.division((divisor:=random_positive_or_negative(randint(15, 25)))*random_positive_or_negative(randint(15, 25)), divisor),    
            choice((
                lambda: self.exponentiation(random_positive_or_negative(randint(13, 19)/10), 2),
                lambda: self.exponentiation(random_positive_or_negative(randint(7, 9)), 3),
                lambda: self.exponentiation(randint(3, 6), 4)
            )),
            choice((
                lambda: self.square_root(round((randint(13, 19)/10)**2, 2)),
                lambda: self.cube_root(choice((7,8,9,11,12))**3)
            )),
            lambda: self.area(Triangle(randint(11, 18), randint(11, 18))),
            choice((
                lambda: self.volume(Cuboid(*sample(range(6, 12), 3))),
                lambda: self.surface_area(Cube(randint(5, 10))),
                lambda: self.surface_area(Cuboid(*sample(range(1, 5), 3)))
            )),
            lambda: self.factorial(randint(6, 8))
        )




