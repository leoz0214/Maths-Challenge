from random import choice


class RandomGreeting:
    """
    A random greeting user receives when they open their account.
    """


    def __init__(self, *greetings):
        self.greeting = choice(greetings)


class MorningGreeting(RandomGreeting):


    def __init__(self):
        super().__init__(
            "Good morning!",
            "Hi there!",
            "Nice to see you!",
            "I hope you are having a good morning."
        )


class AfternoonGreeting(RandomGreeting):


    def __init__(self):
        super().__init__(
            "Good afternoon!",
            "Hi there!",
            "Nice to see you!",
            "I hope you are having a good afternoon."
        )


class EveningGreeting(RandomGreeting):


    def __init__(self):
        super().__init__(
            "Good evening!",
            "Hi there!",
            "Nice to see you!",
            "Hopefully you have had a good day!"
        )


class NightGreeting(RandomGreeting):


    def __init__(self):
        super().__init__(
            "It's getting late!",
            "Hi there!",
            "Nice to see you!",
            "I'm sleepy :)"
        )